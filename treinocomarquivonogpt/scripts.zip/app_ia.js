require('dotenv').config();

const cte_GPT_APIKEY = process.env.GPT_APIKEY;
const cte_GPT_IDASSISTENTE = process.env.GPT_IDASSISTENTE;
const port = process.env.PORT;

let bDebugResponse = ( process.env.DEBUG_RESPONSE == "S" );
let bDebugOpe = ( process.env.DEBUG_OPERACOES == "S" );
let bDebugMsgSemTratamento = ( process.env.DEBUG_MSGSEMTRATAMENTO == "S" );

const { Client, MessageMedia, LocalAuth, Buttons, List } = require('whatsapp-web.js');
const express = require('express');
const socketIO = require('socket.io');
const qrcode = require('qrcode');
const http = require('http');
const https = require('https');
const querystring = require('querystring');
const fs = require('fs');
const { phoneNumberFormatter } = require('./helpers/formatter');
const OpenAI = require('openai');

const cte_TIPOUSO_WHATSAPPJS = 'WHATSAPP.JS';
const cte_FALECONOSCOSITE = "FALE_CONOSCO_SITE";
const cte_NAORESPONDECLIENTE = "NAO_RESPONDE_CLIENTE";

const app = express();
const server = http.createServer(app);
//const io = socketIO(server);
const io = socketIO(server,{
              cors: {
                      origin: "https://isniapps.net",
                      methods: ["GET", "POST"],
                      credentials: true,
                      transports: ['websocket', 'polling'],
              },
              allowEIO3: true
          });          


//Novos 
//const Buttons = require('./node_modules/whatsapp-web.js/src/structures/Buttons.js');

app.use(express.json());
app.use(express.urlencoded({
  extended: true
}));

app.get('/', (req, res) => {
  res.sendFile('index.html', {
    root: __dirname
  });
});

const sessions = [];
const SESSIONS_FILE = './whatsapp-sessions.json';

const threadGPT  = [];
const THREADGPTS_FILE = './thread-sessions.json';

const createSessionsFileIfNotExists = function() {
  if (!fs.existsSync(SESSIONS_FILE)) {
    try {
      fs.writeFileSync(SESSIONS_FILE, JSON.stringify([]));
      console.log('Sessions file created successfully.');
    } catch(err) {
      console.log('Failed to create sessions file: ', err);
    }
  }

  if (!fs.existsSync(THREADGPTS_FILE)) {
    try {
      fs.writeFileSync(THREADGPTS_FILE, JSON.stringify([]));
      console.log('Thread file created successfully.');
    } catch(err) {
      console.log('Failed to create thread file: ', err);
    }
  }
}

createSessionsFileIfNotExists();

const setSessionsFile = function(sessions) {
  fs.writeFile(SESSIONS_FILE, JSON.stringify(sessions), function(err) {
    if (err) {
      console.log(err);
    }
  });
}

const getSessionsFile = function() {
  return JSON.parse(fs.readFileSync(SESSIONS_FILE));
}

const getThreadsFile =  function() {
    return JSON.parse(fs.readFileSync(THREADGPTS_FILE));
}

const setThreadsFile = function(threads) {
    fs.writeFile(THREADGPTS_FILE, JSON.stringify(threads), function(err) {
      if (err) {
        console.log(err);
      }
    });
  }

const createSession = function(id, description) {
  console.log( 'Sessão criada: ' + id);
  const client = new Client({
    restartOnAuthFail: true,
    puppeteer: {
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--single-process', // <- this one doesn't works in Windows
        '--disable-gpu'
      ],
    },
    authStrategy: new LocalAuth({
      clientId: id
    })
  });

  client.initialize();

  client.on('qr', (qr) => {
    //console.log('QR RECEIVED', qr);
    qrcode.toDataURL(qr, (err, url) => {
      io.emit('qr', { id: id, src: url });
      io.emit('message', { id: id, text: 'QR code criado, leia ele por favor!' });
    });
  });

  client.on('ready', () => {
    io.emit('ready', { id: id });
    io.emit('message', { id: id, text: 'Whatsapp está conectado!' });

    console.log('Whatsapp pronto para atender mensagens');

    const savedSessions = getSessionsFile();
    const sessionIndex = savedSessions.findIndex(sess => sess.id == id);
    savedSessions[sessionIndex].ready = true;
    setSessionsFile(savedSessions);
  });

  client.on('authenticated', () => {
    io.emit('authenticated', { id: id });
    io.emit('message', { id: id, text: 'Whatsapp está autenticado!' });
  });

  client.on('auth_failure', function() {
    io.emit('message', { id: id, text: 'Falha de autenticação, reiniciando...' });
  });

  client.on('disconnected', (reason) => {
    io.emit('message', { id: id, text: 'Whatsapp está desconectado!' });
    client.destroy();
    client.initialize();

    // Menghapus pada file sessions
    const savedSessions = getSessionsFile();
    const sessionIndex = savedSessions.findIndex(sess => sess.id == id);
    savedSessions.splice(sessionIndex, 1);
    setSessionsFile(savedSessions);

    io.emit('remove-session', id);
  });

  client.on('message', async msg => {
     const chat = await msg.getChat();
     var sMsgEnviarBot = "";
     var sMsgDoUsuario = msg.body;

    //Se nada respondido
    if( sMsgDoUsuario=="" ){
        sMsgEnviarBot = "Me envie alguma pergunta para eu tentar responder.";
    }

    let sNomeCliente = '';
    let contact = null;
    try{
       contact = await msg.getContact();
       sNomeCliente = contact.pushname;    
    }catch(err){} 

    //Dispara ao typing aqui p simular digitação.
    chat.sendStateTyping();

    if( sMsgEnviarBot == "" ){
        processaPerguntaGPT( sMsgDoUsuario, chat, client, msg.from, sNomeCliente );
    }
    else{
        setTimeout( function(){
                        chat.clearState();
                        client.sendMessage( msg.from, sMsgEnviarBot );
                     }, 5000 );
    }
  });  

  client.on('message_create', (msg) => {
      // Fired on all message creations, including your own
      if (msg.fromMe) {
          // do stuff here
      }
  });

  client.on('message_revoke_everyone', async (after, before) => {
      // Fired whenever a message is deleted by anyone (including you)
      console.log(after); // message after it was deleted.
      if (before) {
          console.log(before); // message before it was deleted.
      }
  });

  client.on('message_revoke_me', async (msg) => {
      // Fired whenever a message is only deleted in your own view.
      console.log(msg.body); // message before it was deleted.
  });

  client.on('message_ack', (msg, ack) => {
      /*
          == ACK VALUES ==
          ACK_ERROR: -1
          ACK_PENDING: 0
          ACK_SERVER: 1
          ACK_DEVICE: 2
          ACK_READ: 3
          ACK_PLAYED: 4
      */
      /*
      const quotedMsg = await msg.getQuotedMessage();
      console.log( `ID: ${quotedMsg.id._serialized}, ack: ` + ack );
      */
      //console.log( `ack: ` + ack );
  });

  client.on('group_join', (notification) => {
      // User has joined or been added to the group.
      console.log('join', notification);
      notification.reply('User joined.');
  });

  client.on('group_leave', (notification) => {
      // User has left or been kicked from the group.
      console.log('leave', notification);
      notification.reply('User left.');
  });

  client.on('group_update', (notification) => {
      // Group picture, subject or description has been updated.
      console.log('update', notification);
  });

  client.on('change_state', state => {
      console.log('CHANGE STATE', state );
  });

  client.on('disconnected', (reason) => {
      console.log('Client was logged out', reason);
  });
 
  /*************************************************************
   * *********************************************************
   * ********************************************************** */ 


  // Tambahkan client ke sessions
  sessions.push({
    id: id,
    description: description,
    client: client
  });

  // Menambahkan session ke file
  const savedSessions = getSessionsFile();
  const sessionIndex = savedSessions.findIndex(sess => sess.id == id);

  if (sessionIndex == -1) {
    savedSessions.push({
      id: id,
      description: description,
      ready: false,
    });
    setSessionsFile(savedSessions);
  }
}

const init = function(socket) {
  const savedSessions = getSessionsFile();

  if (savedSessions.length > 0) {
    if (socket) {
      /**
       * At the first time of running (e.g. restarting the server), our client is not ready yet!
       * It will need several time to authenticating.
       * 
       * So to make people not confused for the 'ready' status
       * We need to make it as FALSE for this condition
       */
      savedSessions.forEach((e, i, arr) => {
        arr[i].ready = false;
      });

      socket.emit('init', savedSessions);
    } else {
      savedSessions.forEach(sess => {
        createSession(sess.id, sess.description);
      });
    }
  }
}

init();

// Socket IO
io.on('connection', function(socket) {
  init(socket);

  socket.on('create-session', function(data) {
    console.log('Create session: ' + data.id);
    createSession(data.id, data.description);
  });
});

server.listen(port, function() {
  console.log( 'Bot no ar na porta ' + port );
  if( cte_GPT_APIKEY!="" && cte_GPT_IDASSISTENTE!="" ){
    console.log( 'Credenciais GPT OK.' );
  }
});

function dumpError(err) {
  var sMsg = "";
  if (typeof err === 'object') {
    if (err.message) {
      sMsg = '\nMessage: ' + err.message;
    }
    if (err.stack) {
      sMsg += '\nStacktrace:';
      sMsg += '====================';
      sMsg += err.stack;
    }
  } else {
    sMsg += 'dumpError :: argument is not an object';
  }

  return sMsg;
}

function processaPerguntaGPT( pPergunta, pChat, pClient, pFrom, pNomeCliente ){
    var bDebug = bDebugOpe;
    var sIdThread = "";

    if( cte_GPT_APIKEY=="" || cte_GPT_IDASSISTENTE=="" ){
        return "Nem todos os parâmetros foram informados para uso da IA.";
    }

    //Pegando thread do gpt vinculada ao zap do cliente
    const savedThreads = getThreadsFile();
    const clientThreads = savedThreads.find( threads => threads.from == pFrom );
    var criacaoUltimaThread = 0;

    if ( clientThreads ){
        sIdThread = clientThreads.id;
        if( clientThreads.cut ){
            criacaoUltimaThread = clientThreads.cut;
        }
    }

    try{
        //"sk-proj-deKGLfJGlnWcAmPmKoH3T3BlbkFJlU9XZX7XlK09D07S3XK9"
        //"asst_HTjFwAZVoEDmsWbrNkxYg6jL"
        const openai = new OpenAI({
            apiKey: cte_GPT_APIKEY
        });

        async function threadCreate( pPergunta ) {
            try{
                const emptyThread = await openai.beta.threads.create();
            
                //console.log(emptyThread);
                if( emptyThread.id ){
                    sIdThread = emptyThread.id;

                    //Tem que salvar a thread criada
                    savedThreads.push( { from: pFrom, id: sIdThread, cut: 0 });
                    setThreadsFile(savedThreads);

                    pPergunta = "O cliente da loja se chama " + pNomeCliente + " e está entrando em contato para saber informações. "
                              + "Por favor responda a seguinte dúvida do cliente: \"" + pPergunta + "\". "
                              + "Caso não saiba a resposta não diga que não encontrou ela nos documentos enviados. "
                              + "Caso não saiba a resposta peça para entrar em contato com o email suporte@lojalegal.com.br.";
                    
                    threadMessage( pPergunta );
                }
                else{
                    //return "Impossível processar resposta da pergunta: falha ao obter thread.";
                    pChat.clearState();
                    pClient.sendMessage( pFrom, "Impossível processar resposta da pergunta: falha ao obter thread." );
                    return;
                }
            }catch(error){
                if( bDebug ){
                    console.log( "Erro na threadCreate: " );
                    console.log( error );
                }                
                //return "Impossível processar resposta da pergunta: falha ao executar threadCreate(2).";
                pChat.clearState();
                pClient.sendMessage( pFrom, "Impossível processar resposta da pergunta: falha ao executar threadCreate(2)." );
                return;
            }
        }

        //Se ainda não tem a Thread, cria ela
        if( sIdThread == "" ){
            threadCreate( pPergunta );
        }
        //Senão, já aproveita 
        else{
            threadMessage( pPergunta );
        }
        
        async function threadMessage( pPergunta ) {
            try{
                console.log( "Pergunta de " + pFrom + " foi enviada" );
                const threadMessages = await openai.beta.threads.messages.create( sIdThread, { role: "user", content: pPergunta } );
                threadRun();
            }catch(error){
                if( bDebug ){
                    console.log( "Erro na threadMessage: " );
                    console.log( error );
                }                
                //return "Impossível processar resposta da pergunta: falha ao executar threadMessage(2).";
                pChat.clearState();
                pClient.sendMessage( pFrom, "Impossível processar resposta da pergunta: falha ao executar threadMessage(2)." );
                return;
            }
        }
        //threadMessage();

        async function threadRun() {
            try{
                const run = await openai.beta.threads.runs.create( sIdThread, { assistant_id: cte_GPT_IDASSISTENTE } );
            
                //console.log(run);
                if( run.id ){
                    sIdRun = run.id;
                    runRetrieve();
                }
                else{
                    //return "Impossível processar resposta da pergunta: falha ao executar run thread.";
                    pChat.clearState();
                    pClient.sendMessage( pFrom, "Impossível processar resposta da pergunta: falha ao executar run thread." );
                    return;
                }
            }catch(error){
                if( bDebug ){
                    console.log( "Erro na threadRun: " );
                    console.log( error );
                }                
                //return "Impossível processar resposta da pergunta: falha ao executar run thread (2).";
                pChat.clearState();
                pClient.sendMessage( pFrom, "Impossível processar resposta da pergunta: falha ao executar run thread (2)." );
                return;
            }
        }
        //threadRun();

        async function runRetrieve() {
            try{
                const run = await openai.beta.threads.runs.retrieve( sIdThread, sIdRun );
            
                //Se já executou a thread...
                if( run.status == "completed" ){
                    threadMessageList();
                }
                //Senão chama o evento que captura o status novamente p ver se ela terminou.
                else{
                    runRetrieve();
                }
            }catch(error){
                if( bDebug ){
                    console.log( "Erro na runRetrieve: " );
                    console.log( error );
                }                
                //return "Impossível processar resposta da pergunta: falha ao executar runRetrieve.";
                pChat.clearState();
                pClient.sendMessage( pFrom, "Impossível processar resposta da pergunta: falha ao executar runRetrieve." );
                return;
            }
        }
        //runRetrieve();

        async function threadMessageList() {
            try{
                const threadMessages = await openai.beta.threads.messages.list( sIdThread );
                var iCriacaoUltimaThread = 0;
            
                //console.log(threadMessages.data);

                for await (const message of threadMessages.data) {
                    //Exibe respostas do assistente
                    if( message.role == "assistant" ){
                        if( message.created_at <= criacaoUltimaThread ){
                            continue;
                        }
                        if( bDebug ){
                            console.log( "conteudo do gpt" );
                            console.log( message.content[0] ); //['value'] );
                            console.log( message.content[0]['text'] ); //['value'] );
                        }
                        var sResposta = message.content[0]['text']['value'];
                        if( bDebug ){
                            console.log( "resposta: " + sResposta );
                        }
                        iPosBlocoEstranho = sResposta.indexOf( "【" );
                        if( iPosBlocoEstranho >= 0 ){
                            sResposta = sResposta.substring( 0, iPosBlocoEstranho );
                        }

                        //return sResposta;
                        pChat.clearState();
                        pClient.sendMessage( pFrom, sResposta );

                        if( iCriacaoUltimaThread < message.created_at ){
                            iCriacaoUltimaThread = message.created_at;
                        }
                    }
                }

                const threadIndex = savedThreads.findIndex( threads => threads.from == pFrom );
                savedThreads[threadIndex].cut = iCriacaoUltimaThread;

                setThreadsFile(savedThreads);

                console.log( "Respondi td para " + pFrom );
            }catch(error){
                if( bDebug ){
                    console.log( "Erro na threadMessageList: " );
                    console.log( error );
                }                
                //return "Impossível processar resposta da pergunta: falha ao executar threadMessageList.";
                pChat.clearState();
                pClient.sendMessage( pFrom, "Impossível processar resposta da pergunta: falha ao executar threadMessageList." );
                return;
            }
        }
    }catch(err){
        //return "Impossível processar resposta da pergunta: " + err.message;
        pChat.clearState();
        pClient.sendMessage( pFrom, "Impossível processar resposta da pergunta: " + err.message );
        return;
    }
}