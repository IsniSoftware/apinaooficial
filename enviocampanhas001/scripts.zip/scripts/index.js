const { Client, MessageMedia, LocalAuth, Buttons, List } = require('whatsapp-web.js');
const express = require('express');
const socketIO = require('socket.io');
const qrcode = require('qrcode');
const http = require('http');
const fs = require('fs');
const readline = require('readline');
const path = require('path');
const formidable = require('formidable');
const { phoneNumberFormatter } = require('./helpers/formatter');
const port = 4500; 

const app = express();
const server = http.createServer(app);
//const io = socketIO(server);
const io = socketIO(server,{
  cors: {
          methods: ["GET", "POST"],
          credentials: true,
          transports: ['websocket', 'polling'],
  },
  allowEIO3: true
}); 

app.use(express.json());
app.use(express.static('public'));
app.use(express.urlencoded({
  extended: true
}));

var FClienteConectado = null;
const sessions = [];
const SESSIONS_FILE = './whatsapp-sessions.json';
const CAMPANHAS_FILE = './campanhas.json';

const createSessionsFileIfNotExists = function() {
  if (!fs.existsSync(SESSIONS_FILE)) {
    try {
      fs.writeFileSync(SESSIONS_FILE, JSON.stringify([]));
      console.log('Arquivo de sessões criado com sucesso.');
    } catch(err) {
      console.log('Falha ao criar arquivo de sessões: ', err);
    }
  }

  if (!fs.existsSync(CAMPANHAS_FILE)) {
    try {
      fs.writeFileSync(CAMPANHAS_FILE, JSON.stringify([]));
      console.log('Arquivo de campanhas criado com sucesso.');
    } catch(err) {
      console.log('Falha ao criar arquivo de campanhas: ', err);
    }
  }
}

createSessionsFileIfNotExists();

const setSessionsFile = function(sessions) {
  fs.writeFile(SESSIONS_FILE, JSON.stringify(sessions), function(err) {
    if (err) {
      console.log(err);
    }
  });
}

const getSessionsFile = function() {
  return JSON.parse(fs.readFileSync(SESSIONS_FILE));
}

const createSession = function(id, description) {
  console.log('Creating session: ' + id);
  const client = new Client({
    restartOnAuthFail: true,
    puppeteer: {
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--single-process', // <- this one doesn't works in Windows
        '--disable-gpu'
      ],
    },
    authStrategy: new LocalAuth({
      clientId: id
    })
  });

  client.initialize();

  client.on('qr', (qr) => {
    //console.log('QR RECEIVED', qr);
    qrcode.toDataURL(qr, (err, url) => {
      io.emit('qr', { id: id, src: url });
      io.emit('message', { id: id, text: 'QR code criado, leia ele por favor!' });
    });
  });

  client.on('ready', () => {
    io.emit('ready', { id: id });
    io.emit('message', { id: id, text: 'Whatsapp está conectado!' });

    const savedSessions = getSessionsFile();
    const sessionIndex = savedSessions.findIndex(sess => sess.id == id);
    savedSessions[sessionIndex].ready = true;
    setSessionsFile(savedSessions);
  });

  client.on('authenticated', () => {
    io.emit('authenticated', { id: id });
    io.emit('message', { id: id, text: 'Whatsapp está autenticado!' });
  });

  client.on('auth_failure', function() {
    io.emit('message', { id: id, text: 'Falha de autenticação, reiniciando...' });
  });

  client.on('disconnected', (reason) => {
    io.emit('message', { id: id, text: 'Whatsapp está desconectado!' });
    client.destroy();
    client.initialize();

    // Menghapus pada file sessions
    const savedSessions = getSessionsFile();
    const sessionIndex = savedSessions.findIndex(sess => sess.id == id);
    savedSessions.splice(sessionIndex, 1);
    setSessionsFile(savedSessions);

    io.emit('remove-session', id);
  });

  /*************************************************************
   * *********************************************************
   * ********************************************************** */ 
  client.on('message', async msg => {
    console.log('MESSAGE RECEIVED', ( msg.body ? msg.body : '' ));

    var arrComandos = new Array();
    arrComandos.push( '!ping --> retorna pong' );
    arrComandos.push( '!ping reply --> retorna pong como resposta' );
    arrComandos.push( '!sendto 55XX9999999 Mensagem --> manda p 55.. uma msg' );
    arrComandos.push( '!reaction --> reage a ultima msg' );
    arrComandos.push( '!echo MSG --> retorna MSG de volta' );
    arrComandos.push( '!info --> imprime dados do contato' );
    arrComandos.push( '!mention --> retorna seu nome' );
    arrComandos.push( '!typing --> simula um "digitando" ' );
    arrComandos.push( '!clearstate --> retira o "digitando" ' );
    
    if (msg.body === '!ping reply') {
        // Send a new message as a reply to the current one
        msg.reply('pong');

    } else if (msg.body === '!ping') {
        // Send a new message to the same chat
        client.sendMessage(msg.from, 'pong');

    } else if (msg.body.startsWith('!sendto ')) {
        // Direct send a new message to specific id
        let number = msg.body.split(' ')[1];
        let messageIndex = msg.body.indexOf(number) + number.length;
        let message = msg.body.slice(messageIndex, msg.body.length);

        client.sendMessage(msg.from, `vou tentar mandar ${message} para ${number}` );

        number = number.includes('@c.us') ? number : `${number}@c.us`;
        let chat = await msg.getChat();
        chat.sendSeen();
        setTimeout( function(){
                      client.sendMessage(number, message);
                    }, 2000 );
    } else if (msg.body.startsWith('!echo ')) {
        // Replies with the same message
        msg.reply(msg.body.slice(6));
    } else if (msg.body === '!info') {
        let info = client.info;
        client.sendMessage(msg.from, `
            *Connection info*
            User name: ${info.pushname}
            My number: ${info.wid.user}
            Platform: ${info.platform}
        `);
    } else if (msg.body === '!mention') {
        const contact = await msg.getContact();
        //console.log( contact );
        const chat = await msg.getChat();
        chat.sendMessage(`Hi @${contact.number}!`, {
            mentions: [contact]
        });
    } else if (msg.body === '!pin') {
        const chat = await msg.getChat();
        await chat.pin();
    } else if (msg.body === '!typing') {
        const chat = await msg.getChat();
        // simulates typing in the chat
        chat.sendStateTyping();
    } else if (msg.body === '!clearstate') {
        const chat = await msg.getChat();
        // stops typing or recording in the chat
        chat.clearState();
    } else if (msg.body === '!buttons') {
        let button = new Buttons('Button body',[{id:'idbt1', body:'bt1'},{body:'bt2'},{body:'bt3'},{body:'bt4'}],'title','footer');
        client.sendMessage(msg.from, button);
    } else if (msg.body === '!buttons2') {
        let button = new Buttons('Button body',[{buttonId:'idbt1', body:'bt1'},{body:'bt2'},{body:'bt3'},{body:'bt4'}],'title','footer');
        client.sendMessage(msg.from, button);
    } else if (msg.body === '!list') {
        let sections = [{title:'sectionTitle1',rows:[{id:'id1.1', title:'ListItem1', description: 'desc 1'},{id:'id1.2', title:'ListItem2', description: 'desc 2'}]},
                        {title:'sectionTitle2',rows:[{id:'id2.3', title:'ListItem3', description: 'desc 3'},{id:'id2.4', title:'ListItem4', description: 'desc 4'}]} ];
        let list = new List('List body','btnText',sections,'Title','footer');
        client.sendMessage(msg.from, list);
    } else if (msg.body === '!list2') {
        let sections = [{rows:[{title:'ListItem1', description: 'desc 1'},{title:'ListItem2', description: 'desc 2'}]} ];
        let list = new List('Msg corpo','btn Chama',sections,'Titulo','Rodape da msg');
        client.sendMessage(msg.from, list);
    } else if (msg.body === '!list3') {
        let sections = [{title:'ListItem1', description: 'desc 1'},{title:'ListItem2', description: 'desc 2'}];
        let list = new List('Msg corpo','btn Chama',sections,'Titulo','Rodape da msg');
        client.sendMessage(msg.from, list);
    } else if (msg.body === '!reaction') {
        msg.react('👍');
    } else if (msg.body === '!sendimg') {
        var sArqMedia = "c:/temp/whatsappweb/imgteste.png";
        var bArquivoExiste = await fs.existsSync( sArqMedia );
        if( bArquivoExiste ){
                  console.log( msg.from ); 
                  const media = MessageMedia.fromFilePath( sArqMedia );
                  const contact = await msg.getContact();
                  const sNOme = "Waldeyr Malinha Sem Alça";
                  const sContato = "553897362418@c.us";

                  await client.sendMessage( sContato, media, { caption : `Olá *${sNOme}*\nOs melhores lançamentos 2024/2025 estão aqui!\nQueima de estoque, você não pode perder essa oportunidade!\nhttps://isnisport.com.br` } ).then( response => {

                      client.sendMessage(msg.from, "Mandei msg p ele, hehehehhe" );
                      //
                  }).catch(err => {
                      client.sendMessage(sContato, "Não consegui enviar o arquivo" );
                      console.log( err );
                  });

                  /*
                  await client.sendMessage( msg.from, media, { caption : `Olá *${contact.name}*\nOs melhores lançamentos 2024/2025 estão aqui!\nQueima de estoque, você não pode perder essa oportunidade!\nhttps://isnisport.com.br` } ).then( response => {
                      //
                  }).catch(err => {
                      client.sendMessage(msg.from, "Não consegui enviar o arquivo" );
                      console.log( err );
                  });
                  */
        }
        else{
          client.sendMessage(msg.from, "Não encontrei o arquivo a ser enviado." );
        }
    }
    /*
    else{
        //msg.react('😕');
        msg.react('😫');
        //msg.reply('não entendi');

        const contact = await msg.getContact();
        const chat = await msg.getChat();

        chat.sendStateTyping();
        chat.sendMessage(`Não entendi @${contact.number} o seu comando!`, {
          mentions: [contact]
        });

        setTimeout( function(){

          var sComandos = '';
          for( var i=0; i<arrComandos.length; i++ ){
             sComandos += arrComandos[i] + '\n';
          }
          
          var sIdBtn = '';
          if( msg.type == 'buttons_response' ){
              sIdBtn = msg.selectedButtonId;
          }
          
          if( sIdBtn != '' ){
              sIdBtn = 'IdResp: ' + sIdBtn + '\n';
          }
  
          //msg.reply('Só entendo isso:\n' + sComandos );
          client.sendMessage( msg.from, sIdBtn + 'Só entendo isso:\n' + sComandos );
        }, 3000 );

    }
    */
  });

  client.on('message_create', (msg) => {
      // Fired on all message creations, including your own
      if (msg.fromMe) {
          // do stuff here
      }
  });

  client.on('message_revoke_everyone', async (after, before) => {
      // Fired whenever a message is deleted by anyone (including you)
      console.log(after); // message after it was deleted.
      if (before) {
          console.log(before); // message before it was deleted.
      }
  });

  client.on('message_revoke_me', async (msg) => {
      // Fired whenever a message is only deleted in your own view.
      console.log(msg.body); // message before it was deleted.
  });

  client.on('message_ack', async (msg, ack) => {
      /*
          == ACK VALUES ==
          ACK_ERROR: -1
          ACK_PENDING: 0
          ACK_SERVER: 1
          ACK_DEVICE: 2
          ACK_READ: 3
          ACK_PLAYED: 4
      */
      /*
      const quotedMsg = await msg.getQuotedMessage();
      console.log( `ID: ${quotedMsg.id._serialized}, ack: ` + ack );
      */
      //console.log( `ack: ` + ack );
      //console.log( msg );
      //const quotedMsg = await msg.getQuotedMessage();
      //console.log( `Msg para ${msg.to}, ack: ` + ack );
  });

  client.on('group_join', (notification) => {
      // User has joined or been added to the group.
      console.log('join', notification);
      notification.reply('User joined.');
  });

  client.on('group_leave', (notification) => {
      // User has left or been kicked from the group.
      console.log('leave', notification);
      notification.reply('User left.');
  });

  client.on('group_update', (notification) => {
      // Group picture, subject or description has been updated.
      console.log('update', notification);
  });

  client.on('change_state', state => {
      console.log('CHANGE STATE', state );
  });

  client.on('disconnected', (reason) => {
      console.log('Client was logged out', reason);
  });
 
  /*************************************************************
   * *********************************************************
   * ********************************************************** */ 


  // Tambahkan client ke sessions
  sessions.push({
    id: id,
    description: description,
    client: client
  });

  FClienteConectado = client;
  
  // Menambahkan session ke file
  const savedSessions = getSessionsFile();
  const sessionIndex = savedSessions.findIndex(sess => sess.id == id);

  if (sessionIndex == -1) {
    savedSessions.push({
      id: id,
      description: description,
      ready: false,
    });
    setSessionsFile(savedSessions);
  }
}

const init = function(socket) {
  const savedSessions = getSessionsFile();

  if (savedSessions.length > 0) {
    if (socket) {
      /**
       * At the first time of running (e.g. restarting the server), our client is not ready yet!
       * It will need several time to authenticating.
       * 
       * So to make people not confused for the 'ready' status
       * We need to make it as FALSE for this condition
       */
      savedSessions.forEach((e, i, arr) => {
        arr[i].ready = false;
      });

      socket.emit('init', savedSessions);
    } else {
      savedSessions.forEach(sess => {
        createSession(sess.id, sess.description);
      });
    }
  }
}

init();

// Socket IO
io.on('connection', function(socket) {
  init(socket);

  socket.on('create-session', function(data) {
    console.log('Create session: ' + data.id);
    createSession(data.id, data.description);
  });
});

// Send message
app.post('/send-message', async (req, res) => {
      console.log(req);

      const sender = req.body.sender;
      const number = phoneNumberFormatter(req.body.number);
      const message = req.body.message;

      if (!sender) {
        return res.status(422).json({
          status: false,
          message: `The sender is empty!`
        })
      }

      const client = sessions.find(sess => sess.id == sender).client;

      // Make sure the sender is exists & ready
      if (!client) {
        return res.status(422).json({
          status: false,
          message: `The sender: ${sender} is not found!`
        })
      }

      /**
       * Check if the number is already registered
       * Copied from app.js
       * 
       * Please check app.js for more validations example
       * You can add the same here!
       */
      const isRegisteredNumber = await client.isRegisteredUser(number);

      if (!isRegisteredNumber) {
        return res.status(422).json({
          status: false,
          message: 'The number is not registered'
        });
      }

      client.sendMessage(number, message).then(response => {
        res.status(200).json({
          status: true,
          response: response
        });
      }).catch(err => {
        res.status(500).json({
          status: false,
          response: err
        });
      });
});

app.get('/excluisession/:id', async (req, res) => {
    var sender = req.params.id;

    const oSessao = sessions.find(sess => sess.id == sender);
    if (!oSessao) {
      return res.status(422).send( `The sender: ${sender} is not found!` );
    }
    
    const client = oSessao.client;
    if (!client) {
      return res.status(422).send( `The sender.client is empty!` );
    }

    //res.send('sessao a ser excluida: ' + sender );
    //return res.status(422).send( 'xxx' );

    try {
        io.emit('message', { id: sender, text: 'Whatsapp está desconectado!' });

        client.logout();
        client.destroy();

        // Menghapus pada file sessions
        const savedSessions = getSessionsFile();
        const sessionIndex = savedSessions.findIndex(sess => sess.id == sender);
        savedSessions.splice(sessionIndex, 1);
        setSessionsFile(savedSessions);

        io.emit('remove-session', sender);

        res.status(200).send( 'Conexao WA removida' );
      }catch(err){
        return res.status(422).send( dumpError(err) );
    }
});

server.listen(port, function() {
  console.log('App running on *: ' + port);
});

function dumpError(err) {
  var sMsg = "";
  if (typeof err === 'object') {
    if (err.message) {
      sMsg = '\nMessage: ' + err.message;
    }
    if (err.stack) {
      sMsg += '\nStacktrace:';
      sMsg += '====================';
      sMsg += err.stack;
    }
  } else {
    sMsg += 'dumpError :: argument is not an object';
  }

  return sMsg;
}

// *********************************************************************************

const getCampanhasFile =  function() {
  return JSON.parse(fs.readFileSync(CAMPANHAS_FILE));
}

const setCampanhasFile = function(lstCampanhas) {
  function compare( a, b ) {
    if ( a.nm < b.nm ){
      return -1;
    }
    if ( a.nm > b.nm ){
      return 1;
    }
    return 0;
  }

  lstCampanhas.sort( compare );

  fs.writeFile(CAMPANHAS_FILE, JSON.stringify(lstCampanhas), function(err) {
    if (err) {
      console.log(err);
    }
  });
}

function salvaCampanha( pCampanha ){
  const savedCampanhas = getCampanhasFile();
  var oIndiceCampanha = savedCampanhas.findIndex( campanhas => campanhas.id == pCampanha.id );

  if ( oIndiceCampanha>=0 ){
      savedCampanhas[oIndiceCampanha].nm = pCampanha.nm;
      savedCampanhas[oIndiceCampanha].ds = pCampanha.ds;
      savedCampanhas[oIndiceCampanha].cd = pCampanha.cd;     
      savedCampanhas[oIndiceCampanha].sc = pCampanha.sc;     
  }
  else{
      savedCampanhas.push( { id: pCampanha.id, nm: pCampanha.nm, ds: pCampanha.ds, cd: pCampanha.cd, sc: pCampanha.sc });
  }
  setCampanhasFile( savedCampanhas );
}

function salvaImgAnexaDaCampanha( pIdCampanha, pImgAnexa ){
  const savedCampanhas = getCampanhasFile();
  var oIndiceCampanha = savedCampanhas.findIndex( campanhas => campanhas.id == pIdCampanha );

  if ( oIndiceCampanha>=0 ){
      //Deve apagar a img anterior
      if( savedCampanhas[oIndiceCampanha].ia != "" ){
          var imgAnexa = 'public/imgsanexas/' + savedCampanhas[oIndiceCampanha].ia;

          if( fs.existsSync(imgAnexa) ){ 
              fs.unlink( imgAnexa, function(err){
                  //console.log( 'Img antiga voi apagada: ' + imgAnexa ); 
              }); 
          }
      }
      savedCampanhas[oIndiceCampanha].ia = pImgAnexa;

      setCampanhasFile( savedCampanhas );
  }
}

async function arquivoToArray( pNomeArquivo, pLinhaIni, pLimite ){
    const fileStream = fs.createReadStream( path.join(__dirname, '/uploads') + '/' + pNomeArquivo );

    const rl = readline.createInterface({input: fileStream,crlfDelay: Infinity});

    var arrLinhasLidas = new Array();
    var iLinhaAtual = 1;
    var iTotalLidas = 0;
    
    for await (const line of rl) {
      // Each line in input.txt will be successively available here as `line`.
      //console.log(`Line from file: ${line}`);
      if( iLinhaAtual >= pLinhaIni ){
          if( line && line!="" ){
            if( pLimite == -1 || iTotalLidas < pLimite ){
              arrLinhasLidas.push( line );
              iTotalLidas++;
            }
          }
      }

      if( pLimite > 0 && iTotalLidas >= pLimite ){
          break;
      }
      iLinhaAtual++;
    }

    return arrLinhasLidas;
}

// *********************************************************************************

app.set('views', __dirname + '\views' );
// Set EJS View Engine**
app.set('view engine','ejs');
// Set HTML engine**
app.engine('html', require('ejs').renderFile);


app.get('/', (req, res) => {
  res.sendFile('index.html', {
    root: __dirname
  });
});

app.get('/conexao', (req, res) => {
  res.sendFile('conexao.html', {
    root: __dirname
  });
});

app.get('/lstcampanhas', (req, res) => {
  var savedCampanhas = getCampanhasFile();
  res.render( __dirname + '\\views\\lstcampanhas.html', { lstCampanhas: JSON.stringify(savedCampanhas) } );
});

app.post('/enviamsgdecampanha', async (req, res) => {
    var sDestino = req.body.destino;
    var sMsgEnviar = req.body.msg;
    var sArquivoAnexo = req.body.arquivoanexo;

    if ( !sDestino || !sMsgEnviar ) {
      return res.status(422).json( { erro: 'Faltam dados para o envio!' });
    }

    sDestino = phoneNumberFormatter(sDestino);

    sDestino = "55" + sDestino;

    // Make sure the sender is exists & ready
    if (!FClienteConectado) {
      return res.status(422).json( { erro: 'The sender is not found!' });
    }

    /**
     * Check if the number is already registered
     * Copied from app.js
     * 
     * Please check app.js for more validations example
     * You can add the same here!
     */
    const isRegisteredNumber = await FClienteConectado.isRegisteredUser(sDestino);

    if (!isRegisteredNumber) {
      return res.status(422).json({ erro: 'The number is not registered' } );
    }

    if( sArquivoAnexo && sArquivoAnexo != "" ){
        sArqMedia = 'public/imgsanexas/' + sArquivoAnexo;

        const media = MessageMedia.fromFilePath( sArqMedia );
        await FClienteConectado.sendMessage( sDestino, media, { caption : sMsgEnviar } ).then( response => {
            return res.status(200).json( { msgenviada: 'S' } );
        }).catch(err => {
            return res.status(500).json( { erro: 'Não foi possível enviar a msg' } );
        });
    }
    else{
        FClienteConectado.sendMessage(sDestino, sMsgEnviar).then(response => {
          return res.status(200).json( { msgenviada: 'S' } );
        }).catch(err => {
          return res.status(500).json( { erro: 'Não foi possível enviar a msg' } );
        });
    }
});  

app.post('/excluicampanha', async (req, res) => {
  var idCampanha = req.body.idcampanha;
  var sErro = "";

  if (!idCampanha) {
    sErro = "Id da campanha a ser excluída não foi informado!";
  } 

  if( sErro != "" ){
    return res.status(422).json({
      status: false,
      message: sErro
    });
  }

  try{
      var savedCampanhas = getCampanhasFile();
      var oIndiceCampanha = savedCampanhas.findIndex( campanhas => campanhas.id == idCampanha );
      var imgAnexa = "";

      if ( oIndiceCampanha>=0 ){
        var campanhasMantidas = [];
        savedCampanhas.forEach( umaCampanha=>{
            if( umaCampanha.id != idCampanha ){
               campanhasMantidas.push( umaCampanha );
            }
            else{
              imgAnexa = umaCampanha.ia;
            }
        });

        setCampanhasFile( campanhasMantidas );        

        if( imgAnexa != "" ){
          fs.unlink( 'public/imgsanexas/' + imgAnexa, function(err){
            //return res.status(200).json({ campanhaexcluida: "S" });
          }); 
        }
        
          return res.status(200).json({ campanhaexcluida: "S" });
        
      }

      return res.status(422).json( { message: "Campanha a ser excluída não foi encontrada." } );
  }catch(err){
      return res.status(422).json( { message: "Não foi possível excluir a campanha." } );
  }  
});

app.get('/enviarcampanha', (req, res) => {
  var idCampanha = req.query.id;
  var sNomeCampanha = "";
  var descCampanha = "";
  var colDestinatario = "";
  var separadorColunas = "";
  var sArquivoAnexo = "";
  var imgAnexa = "";

  if( idCampanha!=undefined && idCampanha!="" ){
      try{
          var savedCampanhas = getCampanhasFile();
          var oCampanha = savedCampanhas.find( campanhas => campanhas.id == idCampanha );

          if( oCampanha ){
            sNomeCampanha = oCampanha.nm;
            descCampanha = oCampanha.ds;
            colDestinatario = oCampanha.cd;
            separadorColunas = oCampanha.sc;
            sArquivoAnexo = oCampanha.ia;
            imgAnexa = oCampanha.ia;

            descCampanha = descCampanha.replace(/<br>/g,'\n');
          }
          else{
            return res.status(422).json( "Campanha a ser enviada não foi encontrada." );
          }
      }catch(err){
          console.log( err );
          return res.status(422).json( "Não foi possível buscar os dados da campanha a ser enviada." );
      }      
  }

  if( imgAnexa && imgAnexa != "" ){
      imgAnexa = "/imgsanexas/" + imgAnexa;
  }

  return res.render( __dirname + '\\views\\enviacampanha.html', { "idCampanha": idCampanha, "nomeCampanha": sNomeCampanha, "descCampanha": descCampanha, "colDestinatario": colDestinatario, "separadorColunas": separadorColunas, "arquivoAnexo": sArquivoAnexo, "imgAnexaCampanha": imgAnexa });
});

app.get('/editacampanha', (req, res) => {
  var idCampanha = req.query.id;
  var sNomeCampanha = "";
  var descCampanha = "";
  var colDestinatario = "";
  var separadorColunas = "";
  var imgAnexa = "";

  if( idCampanha!=undefined && idCampanha!="" ){
      try{
          var savedCampanhas = getCampanhasFile();
          var oCampanha = savedCampanhas.find( campanhas => campanhas.id == idCampanha );

          if( oCampanha ){
            sNomeCampanha = oCampanha.nm;
            descCampanha = oCampanha.ds;
            colDestinatario = oCampanha.cd;
            separadorColunas = oCampanha.sc;
            imgAnexa = oCampanha.ia;

            descCampanha = descCampanha.replace(/<br>/g,'\n');
          }
          else{
            return res.status(422).json( "Campanha a ser editada não foi encontrada." );
          }
      }catch(err){
          console.log( err );
          return res.status(422).json( "Não foi possível exibir os dados da campanha." );
      }      
  }

  if( !imgAnexa ){
    imgAnexa = "semimganexa.png";
    imgAnexa = "/imgs/" + imgAnexa;
  }
  else{
    imgAnexa = "/imgsanexas/" + imgAnexa;
  }

  return res.render( __dirname + '\\views\\editacampanha.html', { "idCampanha": idCampanha, "nomeCampanha": sNomeCampanha, "descCampanha": descCampanha, "colDestinatario": colDestinatario, "separadorColunas": separadorColunas, "imgAnexaCampanha" : imgAnexa });
});

// Send message
app.post('/salvacampanha', async (req, res) => {
    var idCampanha = req.body.idcampanha;
    var nomeCampanha = req.body.nmcampanha;
    var descCampanha = req.body.dscampanha;
    var colunaDestinatario = req.body.coldestinatario;
    var separadorColunas = req.body.separadorcolunas;

    var bDebug = false;

    if( bDebug ){
      console.log( "Na post salvacampanha" );
    }

    var sErro = "";

    if (!nomeCampanha) {
      sErro = "Nome está vazio!";
    } 

    if( sErro != "" ){
      return res.status(422).json({
        status: false,
        message: sErro
      });
    }

    if( bDebug ){
      console.log( "Dados validados, vai salvar..." );
    }

    try{
        //cria o id da campanha
        if (!idCampanha) {
          idCampanha = new Date().valueOf();
        }

        if( descCampanha != "" ){
           descCampanha = descCampanha.replace(/\n/g,'<br>');
           descCampanha = descCampanha.replace(/'/g,'');
           descCampanha = descCampanha.replace(/"/g,'');
        }

        var oCampanha = { id: idCampanha, nm: nomeCampanha, ds: descCampanha, cd: colunaDestinatario, sc: separadorColunas };

        if( bDebug ){
            console.log( "Dados a serem salvos" );
            console.log( oCampanha );
        }

        salvaCampanha( oCampanha );

        res.status(200).json({
            dadossalvos: "S",
            idcampanhasalva: idCampanha
        });
    }catch(err){
        if( bDebug ){
          console.log( "Deu erro ao salvar os dados" );
          console.log( err );
        }

        return res.status(422).json({
          status: false,
          message: "Não foi possível salvar a campanha."
        });
    }
});

app.post('/enviaarquivocampanha', async (req, res) => {
    var iTotalLinhasArq = 0;
    var sNomeArqSalvo = "";
    var form = new formidable.IncomingForm();
    // specify that we want to allow the user to upload multiple files in a single request
    form.multiples = false;
    // store all uploads in the /uploads directory
    form.uploadDir = path.join(__dirname, '/uploads');
    // every time a file has been uploaded successfully,
    // rename it to it's orignal name
    form.on('file', async function(field, file) {
        if( file ){
            sNomeArqSalvo = path.basename( file.filepath );
            var arrLinhasArq = await arquivoToArray( sNomeArqSalvo, 1, -1 );
            iTotalLinhasArq = arrLinhasArq.length;
            res.end('{ "resultado": "sucesso", "nomearquivo": "' + sNomeArqSalvo + '", "totallinhasarq": "' + iTotalLinhasArq + '" }' );
        }
    });

    // log any errors that occur
    form.on('error', function(err) {
      res.end('erro');
    });
    // once all the files have been uploaded, send a response to the client
    form.on('end', function() {
    });
    // parse the incoming request containing the form data
    form.parse(req);
});

app.post( '/learquivocampanha', async (req, res) => {
    var iLinhaAtual = req.body.linha;
    var iMaxLinhas = req.body.maxlinhas;
    var sNomeArquivo = req.body.nome;

    //console.log( "linha atual " + iLinhaAtual + ", lendo " + iMaxLinhas + " linhas " );

    var arrLinhasLidas = await arquivoToArray( sNomeArquivo, iLinhaAtual, iMaxLinhas );

    //console.log( arrLinhasLidas );

    res.status(200).json({
       linhaslidas: arrLinhasLidas
    });
});

app.post('/salvaimganexacampanha', async (req, res) => {
  var idCampanha = "";
  var form = new formidable.IncomingForm();

  // log any errors that occur
  form.on('error', function(err) {
    res.end( '{ "erro": "Não foi possível enviar a imagem (#1)!" }' );
  });
  // once all the files have been uploaded, send a response to the client
  form.on('end', function() {
  });

  // parse the incoming request containing the form data
  form.parse(req, function(err, fields, files) {
    if (err){
        res.end( '{ "erro": "Não foi possível enviar a imagem (#1)!" }' );
    }
    else{
        idCampanha = fields.idcampanha;
        let oldPath = files.arquivoEnvio.filepath;
        let newPath = path.join(__dirname, '/public/imgsanexas') + '/' + files.arquivoEnvio.originalFilename;
        let rawData = fs.readFileSync(oldPath)
        fs.writeFile(newPath, rawData, function (err2) {
            if (err2){
              res.end( '{ "erro": "Não foi possível enviar a imagem (#2)!" }' );
            } 
            else{
              salvaImgAnexaDaCampanha( idCampanha, files.arquivoEnvio.originalFilename );          
              res.end( '{ "resultado": "sucesso" }' );
            }
        });
    }
  });
});

app.get('/alteraimganexacampanha', (req, res) => {
  var idCampanha = req.query.id;
  var sNomeCampanha = "";

  if( idCampanha!=undefined && idCampanha!="" ){
      try{
          var savedCampanhas = getCampanhasFile();
          var oCampanha = savedCampanhas.find( campanhas => campanhas.id == idCampanha );

          if( oCampanha ){
            sNomeCampanha = oCampanha.nm;
            imgAnexa = oCampanha.ia;
          }
          else{
            return res.status(422).json( "Campanha a ser editada não foi encontrada." );
          }
      }catch(err){
          console.log( err );
          return res.status(422).json( "Não foi possível exibir os dados da campanha." );
      }      
  }

  if( !imgAnexa ){
    imgAnexa = "semimganexa.png";
    imgAnexa = "/imgs/" + imgAnexa;
  }
  else{
    imgAnexa = "/imgsanexas/" + imgAnexa;
  }

  return res.render( __dirname + '\\views\\alteraimganexacampanha.html', { "idCampanha": idCampanha, "nomeCampanha": sNomeCampanha, "imgAnexaCampanha" : imgAnexa });
});

app.post('/limpaimganexa', async (req, res) => {
  var idCampanha = req.body.idcampanha;
  var imgAnexa = "";

  if( !idCampanha ){
      return res.end( '{ "erro": "Não foi possível limpar a imagem (#1)!" }' );
  }

  try{
      var savedCampanhas = getCampanhasFile();
      var oCampanha = savedCampanhas.find( campanhas => campanhas.id == idCampanha );

      if( oCampanha ){
        imgAnexa = oCampanha.ia;
      }
      else{
        return res.end( '{ "erro": "Campanha não encontrada (#1)!" }' );
      }
  }catch(err){
      return res.end( '{ "erro": "Campanha não encontrada (#2)!" }' );
  }  

  if( imgAnexa != "" ){
      imgAnexa = 'public/imgsanexas/' + imgAnexa;

      if( fs.existsSync(imgAnexa) ){ 
          fs.unlink( imgAnexa, function(err){
              if(err){
                  return res.end( '{ "erro": "Não foi possível remover a imagem da campanha (#1)!" }' );
              } 
            salvaImgAnexaDaCampanha( idCampanha, "" );
            res.end( '{ "imglimpa": "S" }' );
          }); 
      }
      else{
          salvaImgAnexaDaCampanha( idCampanha, "" );
          res.end( '{ "imglimpa": "S" }' );
      }
  }
  else{
      return res.end( '{ "erro": "Imagem já foi removida!" }' );
  }

});
